// JavaScript for Aerospace Engineering Study Guide

// Toggle solution visibility
document.addEventListener('DOMContentLoaded', function() {
    const solutionButtons = document.querySelectorAll('.show-solution');
    
    solutionButtons.forEach(button => {
        button.addEventListener('click', function() {
            const solutionId = this.getAttribute('data-solution');
            const solutionElement = document.getElementById(solutionId);
            
            if (solutionElement.classList.contains('visible')) {
                solutionElement.classList.remove('visible');
                this.textContent = 'Show Solution';
            } else {
                solutionElement.classList.add('visible');
                this.textContent = 'Hide Solution';
            }
        });
    });

    // Add direct onclick handlers to all solution buttons as a backup
    document.querySelectorAll('.show-solution').forEach(button => {
        const solutionId = button.getAttribute('data-solution');
        button.setAttribute('onclick', `toggleSolution('${solutionId}', this)`);
    });

    // Problem filters
    const searchInput = document.getElementById('search');
    const difficultySelect = document.getElementById('difficulty');
    const topicSelect = document.getElementById('topic');
    
    if (searchInput && difficultySelect && topicSelect) {
        const problemLinks = document.querySelectorAll('.problem-link');
        
        function filterProblems() {
            const searchTerm = searchInput.value.toLowerCase();
            const difficultyFilter = difficultySelect.value;
            const topicFilter = topicSelect.value;
            
            problemLinks.forEach(link => {
                const title = link.querySelector('.problem-title').textContent.toLowerCase();
                const difficulty = link.querySelector('.problem-difficulty')?.textContent.toLowerCase() || '';
                const topic = link.closest('.problem-section').id;
                
                const matchesSearch = title.includes(searchTerm);
                const matchesDifficulty = difficultyFilter === 'all' || difficulty.includes(difficultyFilter.toLowerCase());
                const matchesTopic = topicFilter === 'all' || topic.includes(topicFilter);
                
                if (matchesSearch && matchesDifficulty && matchesTopic) {
                    link.style.display = 'block';
                } else {
                    link.style.display = 'none';
                }
            });
            
            // Show/hide section headers based on visible problems
            document.querySelectorAll('.problem-section').forEach(section => {
                const visibleProblems = section.querySelectorAll('.problem-link[style="display: block"]').length;
                if (visibleProblems > 0) {
                    section.style.display = 'block';
                } else {
                    section.style.display = 'none';
                }
            });
        }
        
        searchInput.addEventListener('input', filterProblems);
        difficultySelect.addEventListener('change', filterProblems);
        topicSelect.addEventListener('change', filterProblems);
    }
});

// Global function for direct onclick handlers
function toggleSolution(solutionId, buttonElement) {
    const solutionElement = document.getElementById(solutionId);
    
    if (solutionElement.classList.contains('visible')) {
        solutionElement.classList.remove('visible');
        buttonElement.textContent = 'Show Solution';
    } else {
        solutionElement.classList.add('visible');
        buttonElement.textContent = 'Hide Solution';
    }
}
